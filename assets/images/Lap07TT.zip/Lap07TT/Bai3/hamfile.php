<!DOCTYPE html>
<html>
<head>
    <title>Xử lý thông tin</title>
</head>
<body>
    <?php
    // Tiếp nhận tham số từ URL
    if (isset($_GET['hoten']) && isset($_GET['namsinh']) && isset($_GET['phai'])) {
        $hoten = $_GET['hoten'];
        $namsinh = $_GET['namsinh'];
        $phai = $_GET['phai'];

        // Xử lý họ tên: Loại bỏ khoảng trắng thừa, gỡ bỏ tag HTML, viết hoa chữ cái đầu của mỗi từ
        $hoten = trim(strip_tags($hoten));
        $hoten = ucwords(strtolower($hoten)); // Viết hoa chữ cái đầu mỗi từ

        // Xử lý năm sinh: ép kiểu về số
        $namsinh = (int)$namsinh;

        // Xử lý phái: nếu phái là 0 thì gán là Nữ, ngược lại là Nam
        if ($phai == 0) {
            $phai = 'Nữ';
        } else {
            $phai = 'Nam';
        }

        // Tính tuổi
        $tuoi = date("Y") - $namsinh;

        // Xóa file thongtin.txt nếu tồn tại
        $file_path = 'thongtin.txt';
        if (file_exists($file_path)) {
            unlink($file_path);
        }

        // Nếu $hoten khác rỗng và $namsinh > 0 thì tạo file thongtin.txt
        if (!empty($hoten) && $namsinh > 0) {
            $file = fopen($file_path, 'w');
            $content = "Họ tên: $hoten\nNăm sinh: $namsinh\nGiới tính: $phai\nTuổi: $tuoi\n";
            fwrite($file, $content);
            fclose($file);

            echo "Thông tin đã được ghi vào file thongtin.txt<br>";
        } else {
            echo "Họ tên không được để trống và năm sinh phải lớn hơn 0.<br>";
        }
    } else {
        echo "Vui lòng nhập đủ thông tin họ tên, năm sinh và phái.<br>";
    }
    ?>
</body>
</html>
