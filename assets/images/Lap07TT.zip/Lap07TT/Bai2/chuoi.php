<!DOCTYPE html>
<html>
<head>
    <title>Xử lý chuỗi và mã hóa</title>
</head>
<body>
    <?php
    // Tiếp nhận tham số số ký tự từ URL, mặc định là 8
    $length = isset($_GET['length']) ? (int)$_GET['length'] : 8;

    // Tạo mật khẩu ngẫu nhiên
    function generatePassword($length) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $password = '';
        for ($i = 0; $i < $length; $i++) {
            $password .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $password;
    }

    $password = generatePassword($length);

    // Hiển thị mật khẩu ngẫu nhiên
    echo "Mật khẩu ngẫu nhiên: " . $password . "<br>";

    // Mã hóa password với md5
    echo "Mã hóa md5: " . md5($password) . "<br>";

    // Mã hóa password với sha1
    echo "Mã hóa sha1: " . sha1($password) . "<br>";

    // Mã hóa password với base64
    echo "Mã hóa base64: " . base64_encode($password) . "<br>";

    // Chuyển mật khẩu thành chữ hoa
    echo "Mật khẩu chữ hoa: " . strtoupper($password) . "<br>";
    ?>
</body>
</html>
