<!DOCTYPE html>
<html>
<head>
    <title>Xử lý ngày tháng</title>
</head>
<body>
    <?php
    // Nhận tham số ngày từ URL, ví dụ: ngay=17/11/2020
    if (isset($_GET['ngay'])) {
        $inputDate = $_GET['ngay'];

        // Chuyển đổi chuỗi ngày thành định dạng thời gian
        $date = DateTime::createFromFormat('d/m/Y', $inputDate);

        // Kiểm tra tính hợp lệ của ngày
        if ($date && $date->format('d/m/Y') === $inputDate) {
            echo "Ngày hợp lệ: " . $inputDate . "<br>";

            // Lấy thứ trong tuần
            echo "Thứ trong tuần: " . $date->format('l') . "<br>";

            // Lấy ngày trong năm
            echo "Ngày trong năm: " . $date->format('z') . "<br>";

        } else {
            echo "Ngày không hợp lệ!<br>";
        }

        // Thêm: Cho biết ngày sinh của bạn là thứ mấy trong tuần
        $birthdate = '15/08/1990';  // Thay đổi thành ngày sinh của bạn
        $birthDateObj = DateTime::createFromFormat('d/m/Y', $birthdate);
        echo "Ngày sinh của bạn là thứ: " . $birthDateObj->format('l') . "<br>";
    } else {
        echo "Không có ngày nào được nhập!";
    }
    ?>
</body>
</html>
