<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Tiếp nhận dữ liệu
    $username = htmlspecialchars(trim($_POST['username']));
    $password = htmlspecialchars(trim($_POST['password']));
    $password2 = htmlspecialchars(trim($_POST['password2']));
    $email = htmlspecialchars(trim($_POST['email']));
    $gender = $_POST['gender'];
    $hobbies = isset($_POST['hobbies']) ? $_POST['hobbies'] : [];
    $image = $_POST['image'];
    $job = $_POST['job'];
    $description = htmlspecialchars(trim($_POST['description']));

    // Kiểm tra mật khẩu
    if ($password !== $password2) {
        echo "Mật khẩu không khớp!";
        exit;
    }

    // Hiện thông tin sau khi đăng ký
    echo "<h2>Thông tin đăng ký</h2>";
    echo "Tên truy cập: $username<br>";
    echo "Email: $email<br>";
    echo "Phái: $gender<br>";
    echo "Sở thích: " . implode(', ', $hobbies) . "<br>";
    echo "Hình đại diện: $image<br>";
    echo "Nghề nghiệp: $job<br>";
    echo "Mô tả bản thân: $description<br>";
}
?>
