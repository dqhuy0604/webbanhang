<?php
session_start();

// Kiểm tra session để xác định trạng thái đăng nhập
if (isset($_SESSION['dalogin']) && $_SESSION['dalogin'] == 1) {
    echo "Đã login";
} else {
    echo "Bạn chưa login";
}
?>
