<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <form action="xulylogin.php" method="post" class="border border-primary col-4 m-auto p-2">
        <div class="form-group">
            <label>Username</label>
            <input name="u" type="text" class="form-control"/>
        </div>
        <div class="form-group">
            <label>Mật khẩu</label>
            <input name="p" type="password" class="form-control"/>
        </div>
        <div class="form-group">
            <input name="nho" type="checkbox"/> Ghi nhớ
        </div>
        <div class="form-group">
            <input name="btn" type="submit" value="Đăng nhập" class="btn btn-primary"/>
        </div>
    </form>
</body>
</html>
