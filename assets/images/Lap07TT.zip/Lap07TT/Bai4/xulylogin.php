<?php
session_start();

if (isset($_POST['u']) && isset($_POST['p'])) {
    // Tiếp nhận dữ liệu từ form và xử lý
    $username = trim(strip_tags($_POST['u']));
    $password = trim(strip_tags($_POST['p']));

    // Hiện username và password (chỉ để kiểm tra)
    echo "Username: $username<br>";
    echo "Password: $password<br>";

    // Xử lý ghi nhớ tài khoản
    if (isset($_POST['nho'])) {
        // Mã hóa password bằng base64
        $encodedPassword = base64_encode($password);

        // Tạo cookie lưu username và password trong 7 ngày
        setcookie('username', $username, time() + (7 * 24 * 60 * 60));
        setcookie('password', $encodedPassword, time() + (7 * 24 * 60 * 60));
    } else {
        // Xóa cookie nếu không chọn "Ghi nhớ"
        setcookie('username', '', time() - 3600);
        setcookie('password', '', time() - 3600);
    }

    // Kiểm tra đăng nhập
    if ($username === 'admin' && $password === 'caphenhe') {
        // Tạo session nếu thông tin đúng
        $_SESSION['dalogin'] = 1;
    } else {
        // Hủy session nếu thông tin sai
        unset($_SESSION['dalogin']);
    }
}
?>
