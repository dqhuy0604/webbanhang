<?php
$tenLoai = trim(strip_tags($_GET['tenLoai'])); // Xử lý dữ liệu
$thuTu = intval($_GET['thuTu']); // Chuyển thành số nguyên
$anHien = intval($_GET['anHien']); // Chuyển thành số nguyên

// Kiểm tra giá trị hợp lệ
if (empty($tenLoai)) {
    die("Tên loại không hợp lệ!");
}
if ($thuTu <= 0) {
    die("Thứ tự phải lớn hơn 0!");
}
if ($anHien !== 0 && $anHien !== 1) {
    die("Ẩn hiện chỉ có thể là 0 hoặc 1!");
}

// Kết nối database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ten_database";

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Chèn dữ liệu vào bảng
$sql = "INSERT INTO loai_san_pham (tenLoai, ThuTu, AnHien) VALUES ('$tenLoai', $thuTu, $anHien)";

if ($conn->query($sql) === TRUE) {
    echo "Chèn dữ liệu thành công!";
} else {
    echo "Lỗi: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
