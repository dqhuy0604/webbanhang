<?php
// Kết nối database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "banlaptop"; // Đổi tên database

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Tiếp nhận và xử lý tham số từ URL
if (isset($_GET['tenLoai']) && isset($_GET['thuTu']) && isset($_GET['anHien'])) {
    $tenLoai = trim(strip_tags($_GET['tenLoai'])); // Loại bỏ thẻ HTML và khoảng trắng
    $thuTu = intval($_GET['thuTu']); // Đảm bảo ThuTu là số
    $anHien = intval($_GET['anHien']); // Đảm bảo AnHien là số

    // Kiểm tra giá trị sau khi xử lý
    echo "Tên loại sau khi xử lý: " . $tenLoai . "<br>";

    // Kiểm tra hợp lệ của dữ liệu
    if (empty($tenLoai)) {
        echo "Tên loại không hợp lệ!";
    } elseif ($thuTu <= 0) {
        echo "Thứ tự phải là số lớn hơn 0!";
    } elseif ($anHien != 0 && $anHien != 1) {
        echo "AnHien chỉ có thể là 0 hoặc 1!";
    } else {
        // Chèn dữ liệu vào database
        $sql = "INSERT INTO LoaiSanPham (tenLoai, ThuTu, AnHien) VALUES ('$tenLoai', '$thuTu', '$anHien')";

        if ($conn->query($sql) === TRUE) {
            echo "Thêm loại sản phẩm thành công!";
        } else {
            echo "Lỗi: " . $sql . "<br>" . $conn->error;
        }
    }
} else {
    echo "Thiếu tham số!";
}

$conn->close();
?>
