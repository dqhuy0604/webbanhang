<?php
$sql = "SELECT TieuDe, SoLanXem FROM tin WHERE NoiBat=1 ORDER BY Ngay DESC LIMIT 0,8";
$kq = $conn->query($sql);
?>

<div id="tinnoibat" class="data">
    <?php foreach ($kq as $tin) { ?>
        <p><?=$tin['TieuDe']?> <span><?=$tin['SoLanXem']?> lượt xem</span></p>
    <?php } ?>
</div>
