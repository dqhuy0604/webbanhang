<h2>THÔNG TIN SẼ HIỆN Ở TRANG CHỦ</h2>
<?php include 'tinmoinhat.php'; ?>
<?php include 'tinnoibat.php'; ?>
