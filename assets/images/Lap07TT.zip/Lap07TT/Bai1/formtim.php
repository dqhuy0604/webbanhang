<!DOCTYPE html>
<html>
<head>
    <title>Form Tìm Kiếm</title>
    <link rel="stylesheet" type="text/css" href="bai1.css">
</head>
<body>
    <form action="xulytimkiem.php" method="get">
        <label for="tukhoa">Từ khóa:</label>
        <input type="text" name="tukhoa" id="tukhoa" />
        <button type="submit">Tìm kiếm</button>
    </form>
</body>
</html>
