<!DOCTYPE html>
<html>
<head>
    <title>Kết Quả Tìm Kiếm</title>
    <link rel="stylesheet" type="text/css" href="bai1.css">
</head>
<body>
    <?php
    if (isset($_GET['tukhoa'])) {
        // Tiếp nhận từ khóa và gỡ bỏ HTML tag, cắt khoảng trắng thừa
        $tukhoa = trim(strip_tags($_GET['tukhoa']));
        echo "Từ khóa bạn tìm kiếm là: " . htmlspecialchars($tukhoa);
    } else {
        echo "Không có từ khóa nào được nhập!";
    }
    ?>
</body>
</html>
