<?php require_once "connectdb.php"; ?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tin Xem Nhiều</title>
    <link rel="stylesheet" href="bai7.css"> 
<body>
<div id="txn" class="data">
    <?php
    try {
        $sql = "SELECT TieuDe, SoLanXem FROM tin WHERE AnHien=1 ORDER BY SoLanXem DESC LIMIT 0,10";
        $kq = $conn->query($sql);
    } catch (Exception $e) {
        die("Lỗi thực thi SQL: " . $e->getMessage());
    }
    ?>

    <?php foreach ($kq as $tin) { ?>
        <p> <?=$tin['TieuDe']?> <span> <?=$tin['SoLanXem']?> lượt xem</span></p>
    <?php } ?>
</div>
</body>
</html>
