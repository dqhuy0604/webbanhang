<?php require_once "connectdb.php"; ?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tin Nổi Bật</title>
    <link rel="stylesheet" href="bai7.css"> 
</head>
<body>
<div id="tinnoibat" class="data">
    <?php
    try {
        $sql = "SELECT TieuDe, SoLanXem FROM tin WHERE NoiBat=1 ORDER BY Ngay DESC LIMIT 0,8";
        $kq = $conn->query($sql);
    } catch (Exception $e) {
        die("Lỗi thực thi SQL: " . $e->getMessage());
    }
    ?>

    <?php foreach ($kq as $tin) { ?>
        <p> <?=$tin['TieuDe']?> <span> <?=$tin['SoLanXem']?> lượt xem</span></p>
    <?php } ?>
</div>
</body>
</html>
