<?php
$servername = "localhost";
$username = "root"; // Điền username MySQL của bạn
$password = ""; // Điền mật khẩu MySQL của bạn
$dbname = "Lap07TT"; // Tên database của bạn

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Thiết lập chế độ báo lỗi của PDO
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Kết nối thất bại: " . $e->getMessage());
}
?>
